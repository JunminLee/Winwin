#ifndef _APP_RESOURCE_ID_H_
#define _APP_RESOURCE_ID_H_

extern const wchar_t* IDC_INTRO;
extern const wchar_t* IDL_FORM;
extern const wchar_t* IDL_FORM2;
extern const wchar_t* IDL_FORM3;
extern const wchar_t* IDL_FORM4;
extern const wchar_t* IDL_FORM5;
extern const wchar_t* IDL_INTRO;
extern const wchar_t* IDSCNT_1;
extern const wchar_t* IDSCNT_2;
extern const wchar_t* IDSCNT_3;
extern const wchar_t* IDSCNT_MAIN_SCENE;
extern const wchar_t* IDC_BUTTON_OK;
extern const wchar_t* IDSCN_1;
extern const wchar_t* MainScene;

#endif // _APP_RESOURCE_ID_H_
