#include "AppResourceId.h"

const wchar_t* IDC_INTRO = L"IDC_INTRO";
const wchar_t* IDL_FORM = L"IDL_FORM";
const wchar_t* IDL_FORM2 = L"IDL_FORM2";
const wchar_t* IDL_FORM3 = L"IDL_FORM3";
const wchar_t* IDL_FORM4 = L"IDL_FORM4";
const wchar_t* IDL_FORM5 = L"IDL_FORM5";
const wchar_t* IDL_INTRO = L"IDL_INTRO";
const wchar_t* IDSCNT_1 = L"IDSCNT_1";
const wchar_t* IDSCNT_2 = L"IDSCNT_2";
const wchar_t* IDSCNT_3 = L"IDSCNT_3";
const wchar_t* IDSCNT_MAIN_SCENE = L"IDSCNT_MAIN_SCENE";
const wchar_t* IDC_BUTTON_OK = L"IDC_BUTTON_OK";
const wchar_t* IDSCN_1 = L"IDSCN_1";
const wchar_t* MainScene = L"MainScene";
