S/W Version Information
Model: Emulator
Tizen-Version: 2.2.1
Build-Number: Tizen_EMULATOR_20131107.2308
Build-Date: 2013.11.07 23:08:36

Crash Information
Process Name: WinWin
PID: 13767
Date: 2014-07-22 04:31:24(GMT+0900)
Executable File Path: /opt/apps/IoDrtebcNP/bin/WinWin
This process is multi-thread process
pid=13767 tid=13767
Signal: 6
      (SIGABRT)
      si_code: -6
      signal sent by tkill (sent by pid 13767, uid 5000)

Register Information
gs  = 0x00000033, fs  = 0x00000000
es  = 0x0000007b, ds  = 0x0000007b
edi = 0xb7335ff4, esi = 0xb7310043
ebp = 0xbff4d248, esp = 0xbff4d230
eax = 0x00000000, ebx = 0x000035c7
ecx = 0x000035c7, edx = 0x00000006
eip = 0xb76f1424

Memory Information
MemTotal:   509428 KB
MemFree:     66348 KB
Buffers:     24848 KB
Cached:     240984 KB
VmPeak:      90796 KB
VmSize:      90792 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       15960 KB
VmRSS:       15960 KB
VmData:       6716 KB
VmStk:         136 KB
VmExe:          40 KB
VmLib:       61120 KB
VmPTE:          96 KB
VmSwap:          0 KB

Maps Information
08048000 08052000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
b214b000 b2159000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnu-i686-1.7.99/module.so
b215a000 b2168000 r-xp /usr/lib/evas/modules/engines/software_x11/linux-gnu-i686-1.7.99/module.so
b2171000 b218b000 r-xp /usr/lib/libnetwork.so.0.0.0
b218d000 b21aa000 r-xp /usr/lib/libwifi-direct.so.0.0
b21ab000 b21b6000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b21b7000 b22dd000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b22e4000 b2311000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b2324000 b2342000 r-xp /opt/usr/apps/IoDrtebcNP/bin/WinWin.exe
b2344000 b23a0000 r-xp /usr/lib/libosp-env-config.so.1.2.2.1
b23a1000 b23f4000 r-xp /usr/lib/libpulsecommon-0.9.23.so
b23f5000 b23fb000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b23fc000 b2401000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2402000 b244a000 r-xp /usr/lib/libpulse.so.0.12.4
b244b000 b244f000 r-xp /usr/lib/libpulse-simple.so.0.0.3
b2450000 b2542000 r-xp /usr/lib/libasound.so.2.0.0
b2546000 b256b000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b256c000 b2580000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2581000 b2662000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b2667000 b26c6000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b26c7000 b26d3000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b26d4000 b26e7000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b26e8000 b26eb000 r-xp /usr/lib/libmm_ta.so.0.0.0
b26ec000 b2703000 r-xp /usr/lib/libICE.so.6.3.0
b2706000 b270d000 r-xp /usr/lib/libSM.so.6.0.1
b270e000 b270f000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2710000 b271b000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b271c000 b2727000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b272b000 b272f000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2730000 b278e000 r-xp /usr/lib/libmmfplayer.so.0.0.0
b2790000 b2798000 r-xp /usr/lib/libxcb-render.so.0.0.0
b2799000 b279b000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b279c000 b27ff000 r-xp /usr/lib/libtiff.so.5.1.0
b2802000 b2854000 r-xp /usr/lib/libturbojpeg.so
b2865000 b286c000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b286d000 b2876000 r-xp /usr/lib/libgif.so.4.1.6
b2877000 b289d000 r-xp /usr/lib/libavutil.so.51.73.101
b28a4000 b28e9000 r-xp /usr/lib/libswscale.so.2.1.101
b28ea000 b2c4f000 r-xp /usr/lib/libavcodec.so.54.59.100
b2f70000 b2f97000 r-xp /usr/lib/libpng12.so.0.50.0
b2f98000 b2f9f000 r-xp /usr/lib/libfeedback.so.0.1.4
b2fa0000 b2faf000 r-xp /usr/lib/libtts.so
b2fb0000 b2fc6000 r-xp /usr/lib/host-gl/libEGL.so.1.0
b2fc7000 b30e1000 r-xp /usr/lib/libcairo.so.2.11200.12
b30e4000 b3109000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b310a000 b3f6e000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.1
b3fe1000 b3fe7000 r-xp /usr/lib/libslp_devman_plugin.so
b3fe8000 b3fec000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b3fed000 b3ff2000 r-xp /usr/lib/libsysman.so.0.2.0
b3ff3000 b400b000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b400c000 b400e000 r-xp /usr/lib/libsystemd-daemon.so.0.0.1
b400f000 b4011000 r-xp /usr/lib/libdeviced.so.0.1.0
b4012000 b402f000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b4030000 b4032000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b4033000 b4036000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b4037000 b403b000 r-xp /usr/lib/libdevice-node.so.0.1
b403c000 b4040000 r-xp /usr/lib/libheynoti.so.0.0.2
b4041000 b40aa000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b40ac000 b40cb000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b40cc000 b40d1000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b40d2000 b40d8000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b40d9000 b40db000 r-xp /usr/lib/libcapi-system-power.so.0.1.1
b40dc000 b40e0000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b40e1000 b40e6000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b40e7000 b40ea000 r-xp /usr/lib/libcapi-network-serial.so.0.0.8
b40eb000 b40ec000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b40ed000 b4100000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b4102000 b4132000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b4133000 b4137000 r-xp /usr/lib/libuuid.so.1.3.0
b4138000 b415f000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b4160000 b4175000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b4176000 b4177000 r-xp /usr/lib/libpmapi.so.1.2
b4178000 b4184000 r-xp /usr/lib/libminizip.so.1.0.0
b4185000 b4194000 r-xp /usr/lib/libmessage-port.so.1.2.2.1
b4195000 b42de000 r-xp /usr/lib/libxml2.so.2.7.8
b42e4000 b430c000 r-xp /usr/lib/libpcre.so.0.0.1
b430d000 b4310000 r-xp /usr/lib/libiniparser.so.0
b4312000 b4317000 r-xp /usr/lib/libhaptic.so.0.1
b4318000 b4319000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b431a000 b4321000 r-xp /usr/lib/libdevman.so.0.1
b4322000 b4328000 r-xp /usr/lib/libchromium.so.1.0
b4329000 b4331000 r-xp /usr/lib/libappsvc.so.0.1.0
b4332000 b4334000 r-xp /usr/lib/osp/libappinfo.so.1.2.2.1
b4335000 b433d000 r-xp /usr/lib/libalarm.so.0.0.0
b433e000 b4348000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.3
b4349000 b4362000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.5
b4363000 b47f6000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.1
b4817000 b4821000 r-xp /lib/libnss_files-2.13.so
b4823000 b482c000 r-xp /lib/libnss_nis-2.13.so
b482e000 b4841000 r-xp /lib/libnsl-2.13.so
b4845000 b484b000 r-xp /lib/libnss_compat-2.13.so
b4b6d000 b4b85000 r-xp /usr/lib/libcom-core.so.0.0.1
b4b86000 b4b89000 r-xp /usr/lib/libdri2.so.0.0.0
b4b8a000 b4b95000 r-xp /usr/lib/libdrm.so.2.4.0
b4b96000 b4b9b000 r-xp /usr/lib/libtbm.so.1.0.0
b4b9c000 b4ba0000 r-xp /usr/lib/libXv.so.1.0.0
b4ba1000 b4cbe000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4ccd000 b4ce3000 r-xp /usr/lib/libnotification.so.0.1.0
b4ce4000 b4ced000 r-xp /usr/lib/libutilX.so.1.1.0
b4cee000 b4d21000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4d23000 b4d34000 r-xp /lib/libresolv-2.13.so
b4d38000 b4d3b000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4d3c000 b4eac000 r-xp /usr/lib/libcrypto.so.1.0.0
b4ec4000 b4f1a000 r-xp /usr/lib/libssl.so.1.0.0
b4f1f000 b4f4e000 r-xp /usr/lib/libidn.so.11.5.44
b4f4f000 b4f5e000 r-xp /usr/lib/libcares.so.2.0.0
b4f5f000 b4f86000 r-xp /lib/libexpat.so.1.5.2
b4f88000 b4fbb000 r-xp /usr/lib/libicule.so.48.1
b4fbc000 b4fc7000 r-xp /usr/lib/libsf_common.so
b4fc8000 b50a4000 r-xp /usr/lib/libstdc++.so.6.0.14
b50b0000 b5215000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b5219000 b524a000 r-xp /usr/lib/libexif.so.12.3.3
b5257000 b5263000 r-xp /usr/lib/libethumb.so.1.7.99
b5264000 b52c8000 r-xp /usr/lib/libsndfile.so.1.0.25
b52ce000 b52d1000 r-xp /usr/lib/libctxdata.so.0.0.0
b52d2000 b52e9000 r-xp /usr/lib/libremix.so.0.0.0
b52ea000 b52ec000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b52ed000 b531a000 r-xp /usr/lib/liblua-5.1.so
b531b000 b5325000 r-xp /usr/lib/libembryo.so.1.7.99
b5326000 b5329000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b532a000 b538b000 r-xp /usr/lib/libcurl.so.4.3.0
b538d000 b5393000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b5394000 b542b000 r-xp /usr/lib/libpixman-1.so.0.28.2
b5430000 b5465000 r-xp /usr/lib/libfontconfig.so.1.5.0
b5467000 b54ec000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b54f6000 b550c000 r-xp /usr/lib/libfribidi.so.0.3.1
b550d000 b5592000 r-xp /usr/lib/libfreetype.so.6.8.1
b5596000 b55dd000 r-xp /usr/lib/libjpeg.so.8.0.2
b55ee000 b560d000 r-xp /lib/libz.so.1.2.5
b560e000 b561e000 r-xp /usr/lib/libsensor.so.1.1.0
b5621000 b5624000 r-xp /usr/lib/libapp-checker.so.0.1.0
b5625000 b562e000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6737000 b6892000 r-xp /usr/lib/libicuuc.so.48.1
b68a0000 b6a7f000 r-xp /usr/lib/libicui18n.so.48.1
b6a86000 b6a89000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6a8a000 b6a96000 r-xp /usr/lib/libvconf.so.0.2.45
b6a97000 b6aa9000 r-xp /usr/lib/libail.so.0.1.0
b6aaa000 b6acf000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b6ad0000 b6ad5000 r-xp /usr/lib/libffi.so.5.0.10
b6ad6000 b6ad7000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b6ad8000 b6ae9000 r-xp /usr/lib/libXext.so.6.4.0
b6aea000 b6aef000 r-xp /usr/lib/libXtst.so.6.1.0
b6af0000 b6af8000 r-xp /usr/lib/libXrender.so.1.3.0
b6af9000 b6b02000 r-xp /usr/lib/libXrandr.so.2.2.0
b6b03000 b6b11000 r-xp /usr/lib/libXi.so.6.1.0
b6b12000 b6b16000 r-xp /usr/lib/libXfixes.so.3.1.0
b6b17000 b6b19000 r-xp /usr/lib/libXgesture.so.7.0.0
b6b1a000 b6b1c000 r-xp /usr/lib/libXcomposite.so.1.0.0
b6b1d000 b6b1f000 r-xp /usr/lib/libXdamage.so.1.1.0
b6b20000 b6b2a000 r-xp /usr/lib/libXcursor.so.1.0.2
b6b2b000 b6b37000 r-xp /usr/lib/libemotion.so.1.7.99
b6b38000 b6b63000 r-xp /usr/lib/libecore_con.so.1.7.99
b6b65000 b6b6d000 r-xp /usr/lib/libecore_imf.so.1.7.99
b6b6e000 b6b79000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6b7a000 b6b7d000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6b7e000 b6b84000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6b85000 b6ba7000 r-xp /usr/lib/libefreet.so.1.7.99
b6ba9000 b6bb5000 r-xp /usr/lib/libedbus.so.1.7.99
b6bb6000 b6c4d000 r-xp /usr/lib/libedje.so.1.7.99
b6c4f000 b6c66000 r-xp /usr/lib/libecore_input.so.1.7.99
b6c7a000 b6c81000 r-xp /usr/lib/libecore_file.so.1.7.99
b6c82000 b6caf000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6cb1000 b6d0c000 r-xp /usr/lib/libeina.so.1.7.99
b6d0e000 b6e18000 r-xp /usr/lib/libevas.so.1.7.99
b6e33000 b6e50000 r-xp /usr/lib/libeet.so.1.7.99
b6e51000 b6e75000 r-xp /lib/libm-2.13.so
b6e77000 b6e7d000 r-xp /usr/lib/libappcore-common.so.1.1
b6e7e000 b6e8e000 r-xp /usr/lib/libaul.so.0.1.0
b6e8f000 b6edf000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6ee0000 b6f23000 r-xp /usr/lib/libecore_x.so.1.7.99
b6f25000 b6f44000 r-xp /usr/lib/libecore.so.1.7.99
b6f53000 b7125000 r-xp /usr/lib/libelementary.so.1.7.99
b7131000 b713e000 r-xp /usr/lib/libcapi-network-connection.so.0.1.3_18
b713f000 b7141000 r-xp /opt/usr/apps/IoDrtebcNP/bin/WinWin
b7144000 b7148000 r-xp /lib/libattr.so.1.1.0
b7149000 b714b000 r-xp /usr/lib/libXau.so.6.0.0
b714c000 b7153000 r-xp /lib/librt-2.13.so
b7156000 b715e000 r-xp /lib/libcrypt-2.13.so
b7187000 b718a000 r-xp /lib/libcap.so.2.21
b718b000 b718d000 r-xp /usr/lib/libiri.so
b718e000 b71a8000 r-xp /lib/libgcc_s-4.5.3.so.1
b71a9000 b71c9000 r-xp /usr/lib/libxcb.so.1.1.0
b71cb000 b71d4000 r-xp /lib/libunwind.so.8.0.1
b71de000 b7334000 r-xp /lib/libc-2.13.so
b733a000 b733f000 r-xp /usr/lib/libsmack.so.1.0.0
b7340000 b738c000 r-xp /usr/lib/libdbus-1.so.3.7.2
b738d000 b7392000 r-xp /usr/lib/libbundle.so.0.1.22
b7393000 b7395000 r-xp /lib/libdl-2.13.so
b7397000 b74c0000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b74c1000 b756b000 r-xp /usr/lib/libsqlite3.so.0.8.6
b756e000 b7580000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b7581000 b76b6000 r-xp /usr/lib/libX11.so.6.3.0
b76ba000 b76cf000 r-xp /lib/libpthread-2.13.so
b76d5000 b76d6000 r-xp /usr/lib/libdlog.so.0.0.0
b76d7000 b76d9000 r-xp /usr/lib/libXinerama.so.1.0.0
b76da000 b76e0000 r-xp /usr/lib/libecore_fb.so.1.7.99
b76e2000 b76e7000 r-xp /usr/lib/libappcore-efl.so.1.1
b76e9000 b76ed000 r-xp /usr/lib/libsys-assert.so
b76f1000 b76f2000 r-xp [vdso]
b76f2000 b770e000 r-xp /lib/ld-2.13.so
End of Maps Information

Callstack Information (PID:13767)
Call Stack Count: 26
 0: __assert_fail + 0xf8 (0xb7201888) [/lib/libc.so.6] + 0x23888
 1: SysAssertfInternal + 0x107 (0xb44daa67) [/usr/lib/osp/libosp-appfw.so] + 0x177a67
 2: Tizen::App::_UiAppImpl::OnAppInitialized() + 0x14b (0xb3b24c1b) [/usr/lib/osp/libosp-uifw.so] + 0xa1ac1b
 3: Tizen::App::_AppImpl::OnService(service_s*, void*) + 0x3e4 (0xb4468eb4) [/usr/lib/osp/libosp-appfw.so] + 0x105eb4
 4: app_appcore_reset + 0x49 (0xb40f1719) [/usr/lib/libcapi-appfw-application.so.0] + 0x4719
 5: __do_app + 0x2bb (0xb76e468b) [/usr/lib/libappcore-efl.so.1] + 0x268b
 6: __aul_handler + 0xc0 (0xb6e78bb0) [/usr/lib/libappcore-common.so.1] + 0x1bb0
 7: app_start + 0x43 (0xb6e81663) [/usr/lib/libaul.so.0] + 0x3663
 8: __app_start_internal + 0x22 (0xb6e82502) [/usr/lib/libaul.so.0] + 0x4502
 9: g_idle_dispatch + 0x21 (0xb73dca91) [/usr/lib/libglib-2.0.so.0] + 0x45a91
10: g_main_context_dispatch + 0x133 (0xb73dfa13) [/usr/lib/libglib-2.0.so.0] + 0x48a13
11: _ecore_glib_select + 0x3fb (0xb6f38deb) [/usr/lib/libecore.so.1] + 0x13deb
12: _ecore_main_select + 0x3a5 (0xb6f32625) [/usr/lib/libecore.so.1] + 0xd625
13: _ecore_main_loop_iterate_internal + 0x3b9 (0xb6f33179) [/usr/lib/libecore.so.1] + 0xe179
14: ecore_main_loop_begin + 0x3f (0xb6f334ef) [/usr/lib/libecore.so.1] + 0xe4ef
15: elm_run + 0x17 (0xb7044717) [/usr/lib/libelementary.so.1] + 0xf1717
16: appcore_efl_main + 0x42e (0xb76e512e) [/usr/lib/libappcore-efl.so.1] + 0x312e
17: app_efl_main + 0xe8 (0xb40f1bf8) [/usr/lib/libcapi-appfw-application.so.0] + 0x4bf8
18: Tizen::App::_AppImpl::Execute(Tizen::App::_IAppImpl*) + 0x129 (0xb4464779) [/usr/lib/osp/libosp-appfw.so] + 0x101779
19: Tizen::App::UiApp::Execute(Tizen::App::UiApp* (*)(), Tizen::Base::Collection::IList const*) + 0xa1 (0xb3b24721) [/usr/lib/osp/libosp-uifw.so] + 0xa1a721
20: OspMain + 0x19f (0xb2335f3f) [/opt/apps/IoDrtebcNP/bin/WinWin.exe] + 0x11f3f
21: main + 0x25a (0xb713ff4a) [/opt/apps/IoDrtebcNP/bin/WinWin] + 0xf4a
22: __launchpad_main_loop + 0x17e0 (0x804bae0) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x804bae0
23: main + 0x685 (0x804ca25) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x804ca25
24: __libc_start_main + 0xe6 (0xb71f4da6) [/lib/libc.so.6] + 0x16da6
25: (0x8049e01) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x8049e01
End of Call Stack

Package Information
Package Name: IoDrtebcNP.WinWin
Package ID : IoDrtebcNP
Version: 1.0.0
Package Type: tpk
App Name: WinWin
App ID: IoDrtebcNP.WinWin
Type: Application
Categories: (NULL)

Latest Debug Message Information
--------- beginning of /dev/log_main
07-22 03:50:07.061 I/osp-installer(11633): bool __osp_installer_report_result(const Tizen::App::PackageId&, int)(320) >  # errorType = [0]
07-22 03:50:07.061 I/osp-installer(11633): bool __osp_installer_report_result(const Tizen::App::PackageId&, int)(321) > ------------------------------------------
07-22 03:50:07.731 I/WinWin  (11683): int OspMain(int, char **)(21) > Application started.
07-22 03:50:07.781 E/Tizen::Io(11683): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-22 03:52:40.451 E/Tizen::Base::Runtime(11904): static Tizen::Base::Runtime::_EventManager* Tizen::Base::Runtime::_EventManager::GetCurrentEventManager()(292) > [E_OBJ_NOT_FOUND] This is not OSP thread.
07-22 03:52:40.451 E/Tizen::Base::Runtime(11904): result Tizen::Base::Runtime::_Event::Initialize()(207) > [E_INVALID_OPERATION] Event manager does not exist.
07-22 03:52:40.451 I/osp-installer(11904): int main(int, char**)(72) >  # argv[0] = [/usr/etc/package-manager/backend/tpk]
07-22 03:52:40.451 I/osp-installer(11904): int main(int, char**)(72) >  # argv[1] = [-k]
07-22 03:52:40.451 I/osp-installer(11904): int main(int, char**)(72) >  # argv[2] = [IoDrtebcNP_-1669162084]
07-22 03:52:40.451 I/osp-installer(11904): int main(int, char**)(72) >  # argv[3] = [-r]
07-22 03:52:40.451 I/osp-installer(11904): int main(int, char**)(72) >  # argv[4] = [IoDrtebcNP]
07-22 03:52:40.451 I/osp-installer(11904): int main(int, char**)(72) >  # argv[5] = [-q]
07-22 03:52:40.461 I/osp-installer(11904): int main(int, char**)(161) >  # path = [IoDrtebcNP]
07-22 03:52:40.461 I/osp-installer(11904): int main(int, char**)(270) > rdsPackage = IoDrtebcNP
07-22 03:52:40.461 I/osp-installer(11904): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(145) > ------------------------------------------
07-22 03:52:40.461 I/osp-installer(11904): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(146) > InstallerManager
07-22 03:52:40.461 I/osp-installer(11904): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(147) > ------------------------------------------
07-22 03:52:40.461 I/osp-installer(11904): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(148) >  # operation = [Reinstall]
07-22 03:52:40.461 I/osp-installer(11904): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(149) >  # path      = [IoDrtebcNP]
07-22 03:52:40.461 I/osp-installer(11904): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(150) > ------------------------------------------
07-22 03:52:40.461 I/osp-installer(11904): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(250) > operation is INSTALLER_OPERATION_REINSTALL
07-22 03:52:40.491 I/osp-installer(11904): static bool InstallerManager::SendEvent(void*, const Tizen::App::PackageId&, const Tizen::Base::String&, const Tizen::Base::String&)(1042) > pkgmgr_installer_send_signal(tpk, IoDrtebcNP, start, update)
07-22 03:52:40.491 I/osp-installer(11904): Installer* InstallerManager::CreateInstaller(InstallerType)(295) > InstallerType = [DirectoryInstaller]
07-22 03:52:40.491 I/osp-installer(11904): bool SmackManager::Begin()(312) > [smack] perm_begin()
07-22 03:52:40.561 I/osp-installer(11904): bool SmackManager::Begin()(314) > [smack] perm_begin(), result = [0]
07-22 03:52:40.571 I/osp-installer(11904): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(891) > .rds_delta file
07-22 03:52:40.571 I/osp-installer(11904): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(927) > .rds_delta: line(001)=[#delete]
07-22 03:52:40.571 I/osp-installer(11904): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(927) > .rds_delta: line(002)=[#add]
07-22 03:52:40.571 I/osp-installer(11904): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(927) > .rds_delta: line(003)=[#modify]
07-22 03:52:40.571 I/osp-installer(11904): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(927) > .rds_delta: line(004)=[author-signature.xml]
07-22 03:52:40.571 I/osp-installer(11904): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(927) > .rds_delta: line(005)=[signature1.xml]
07-22 03:52:40.571 I/osp-installer(11904): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(927) > .rds_delta: line(006)=[bin/WinWin.exe]
07-22 03:52:40.571 I/osp-installer(11904): bool SignatureManager::ValidatePartialReferences(const Tizen::Base::String&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(284) > ValidatePartialReferences start >>
07-22 03:52:40.571 I/osp-installer(11904): bool SignatureManager::ValidatePartialReferences(const Tizen::Base::String&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(291) > rootPath = [/opt/usr/apps/tmp/IoDrtebcNP/]
07-22 03:52:40.571 I/osp-installer(11904): bool SignatureManager::ValidatePartialReferences(const Tizen::Base::String&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(299) > ValidationCore::VCoreInit() returns 1
07-22 03:52:40.571 I/osp-installer(11904): bool SignatureManager::ValidatePartialReferences(const Tizen::Base::String&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(312) > SignatureFiles: file = [signature1.xml]
07-22 03:52:40.571 I/osp-installer(11904): bool SignatureManager::ValidatePartialReferences(const Tizen::Base::String&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(313) > SignatureFiles: number = [1]
07-22 03:52:40.591 I/osp-installer(11904): bool SignatureManager::ValidatePartialReferences(const Tizen::Base::String&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(346) > Default distributor cert value = [MIICmzCCAgQCCQDXI7WLdVZwiTANBgkqhkiG9w0BAQUFADCBjzELMAkGA1UEBhMCS1IxDjAMBgNVBAgMBVN1d29uMQ4wDAYDVQQHDAVTdXdvbjEWMBQGA1UECgwNVGl6ZW4gVGVzdCBDQTEiMCAGA1UECwwZVGl6ZW4gRGlzdHJpYnV0b3IgVGVzdCBDQTEkMCIGA1UEAwwbVGl6ZW4gUHVibGljIERpc3RyaWJ1dG9yIENBMB4XDTEyMTAyOTEzMDMwNFoXDTIyMTAyNzEzMDMwNFowgZMxCzAJBgNVBAYTAktSMQ4wDAYDVQQIDAVTdXdvbjEOMAwGA1UEBwwFU3V3b24xFjAUBgNVBAoMDVRpemVuIFRlc3QgQ0ExIjAgBgNVBAsMGVRpemVuIERpc3RyaWJ1dG9yIFRlc3QgQ0ExKDAmBgNVBAMMH1RpemVuIFB1YmxpYyBEaXN0cmlidXRvciBTaWduZXIwgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBALtMvlc5hENK90ZdA+y66+Sy0enD1gpZDBh5T9RP0oRsptJv5jjNTseQbQi0SZOdOXb6J7iQdlBCtR343RpIEz8HmrBy7mSY7mgwoU4EPpp4CTSUeAuKcmvrNOngTp5Hv7Ngf02TTHOLK3hZLpGayaDviyNZB5PdqQdBhokKjzAzAgMBAAEwDQYJKoZIhvcNAQEFBQADgYEAvGp1gxxAIlFfhJH1efjb9BJK/rtRkbYn9+EzGEbEULg1svsgnyWisFimI3uFvgI/swzr1eKVY3Sc8MQ3+Fdy3EkbDZ2+WAubhcEkorTWjzWz2fL1vKa
07-22 03:52:40.591 I/osp-installer(11904): bool SignatureManager::ValidatePartialReferences(const Tizen::Base::String&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(346) > Default distributor cert value = [MIICtDCCAh2gAwIBAgIJAMDbehElPNKvMA0GCSqGSIb3DQEBBQUAMIGVMQswCQYDVQQGEwJLUjEOMAwGA1UECAwFU3V3b24xDjAMBgNVBAcMBVN1d29uMRYwFAYDVQQKDA1UaXplbiBUZXN0IENBMSMwIQYDVQQLDBpUVGl6ZW4gRGlzdHJpYnV0b3IgVGVzdCBDQTEpMCcGA1UEAwwgVGl6ZW4gUHVibGljIERpc3RyaWJ1dG9yIFJvb3QgQ0EwHhcNMTIxMDI5MTMwMjUwWhcNMjIxMDI3MTMwMjUwWjCBjzELMAkGA1UEBhMCS1IxDjAMBgNVBAgMBVN1d29uMQ4wDAYDVQQHDAVTdXdvbjEWMBQGA1UECgwNVGl6ZW4gVGVzdCBDQTEiMCAGA1UECwwZVGl6ZW4gRGlzdHJpYnV0b3IgVGVzdCBDQTEkMCIGA1UEAwwbVGl6ZW4gUHVibGljIERpc3RyaWJ1dG9yIENBMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDeOTS/3nXvkDEmsFCJIvRlQ3RKDcxdWJJp625pFqHdmoJBdV+x6jl1raGK2Y1sp2Gdvpjc/z92yzApbE/UVLPh/tRNZPeGhzU4ejDDm7kzdr2f7Ia0U98K+OoY12ucwg7TYNItj9is7Cj4blGfuMDzd2ah2AgnCGlwNwV/pv+uVQIDAQABoxAwDjAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBBQUAA4GBACqJKO33YdoGudwanZIxMdXuxnnD9R6u72ltKk1S4zPfMJJv482CRGCI4FK6djhlsI4i0Lt1SVIJEed+yc3
07-22 03:52:40.591 I/osp-installer(11904): bool SignatureManager::ValidatePartialReferences(const Tizen::Base::String&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(384) > modified = [bin/WinWin.exe]
07-22 03:52:40.591 I/osp-installer(11904): bool SignatureManager::ValidatePartialReferences(const Tizen::Base::String&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(394) > uriList.size = [1]
07-22 03:52:40.791 I/osp-installer(11904): bool SignatureManager::ValidatePartialReferences(const Tizen::Base::String&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(398) > Signature validator.checkList() success, file = [signature1.xml], number = [1]
07-22 03:52:40.791 I/osp-installer(11904): bool SignatureManager::ValidatePartialReferences(const Tizen::Base::String&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(312) > SignatureFiles: file = [author-signature.xml]
07-22 03:52:40.791 I/osp-installer(11904): bool SignatureManager::ValidatePartialReferences(const Tizen::Base::String&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(313) > SignatureFiles: number = [-1]
07-22 03:52:40.801 I/osp-installer(11904): bool SignatureManager::ValidatePartialReferences(const Tizen::Base::String&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(339) > Author cert value = [MIIClTCCAX2gAwIBAgIGAUcrnHnmMA0GCSqGSIb3DQEBBQUAMFYxGjAYBgNVBAoMEVRpemVuIEFzc29jaWF0aW9uMRowGAYDVQQLDBFUaXplbiBBc3NvY2lhdGlvbjEcMBoGA1UEAwwTVGl6ZW4gRGV2ZWxvcGVycyBDQTAeFw0xMjExMDEwMDAwMDBaFw0xOTAxMDEwMDAwMDBaMBExDzANBgNVBAMMBmF1dGhvcjCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAkSMrcuj6qd8kvc2wiOTMvDXhCJPJeZ34D3jCAil0YBiDQHWvhHniZMtnDIHLO5aDMSzu8l+IC1HF2/6BKj/HXwp5ZuBwb3tG9vBUMFfFnWVn+H/jffRZupuT3OKR1N9bpmx3dmq5KaTO1CpJX4n1eJWXvw5gLKYXT1YD2HqV6fECAwEAAaMyMDAwDAYDVR0TAQH/BAIwADALBgNVHQ8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwDQYJKoZIhvcNAQEFBQADggEBALg/IbnXBacNR3MA+4AnZIyphgzVJA3m5bi2J1qVmb/Cx9/uMXUQgVjNMipzbTMbisMXpSiF+BwxAHKRJeEdKcgQcyLiXz1mCsOBIeQutdBgyPx2hL7JKjTQsxTLTxk4Dc2XFHD4Nk9QLqMfzHD6Zn3lcCsbi2S+z94We3Pr276/ec15fiWsGcPYJcfrBxq2wvQgYrL0Cb2hzPlFMXqfjfTp5wH0GFpKFZwltLzBP3NNd1jpI8SIdH+czSp/a0xp2ua97FNJuHPxA9XDVyDo/5cErY9p2pjGDgxN+yDh5wOmnyr1Hkqd
07-22 03:52:40.801 I/osp-installer(11904): bool SignatureManager::ValidatePartialReferences(const Tizen::Base::String&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(339) > Author cert value = [MIIDOTCCAiGgAwIBAgIBATANBgkqhkiG9w0BAQUFADBYMRowGAYDVQQKDBFUaXplbiBBc3NvY2lhdGlvbjEaMBgGA1UECwwRVGl6ZW4gQXNzb2NpYXRpb24xHjAcBgNVBAMMFVRpemVuIERldmVsb3BlcnMgUm9vdDAeFw0xMjAxMDEwMDAwMDBaFw0yNzAxMDEwMDAwMDBaMFYxGjAYBgNVBAoMEVRpemVuIEFzc29jaWF0aW9uMRowGAYDVQQLDBFUaXplbiBBc3NvY2lhdGlvbjEcMBoGA1UEAwwTVGl6ZW4gRGV2ZWxvcGVycyBDQTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANVGhRGmMIUyBA7oPCz8Sxut6z6HNkF4oDIuzuKaMzRYPeWodwe9O0gmqAkToQHfwg2giRhE5GoPld0fq+OYMMwSasCug8dwODx1eDeSYVuOLWRxpAmbTXOsSFi6VoWeyaPEm18JBHvZBsU5YQtgZ6Kp7MqzvQg3pXOxtajjvyHxiatJl+xXrHgcXC1wgyG3buty7u/Fi2mvKXJ0PRJcCjjK81dqe/Vr20sRUCrbk02zbm5ggFt/jIEhV8wbFRQpliobc7J4dSTKhFfrqGM8rdd54LYhD7gSI1CFSe16pUXfcVR7FhJztRaiGLnCrwBEdyTZ248+D4L/qR/D0axb3jcCAwEAAaMQMA4wDAYDVR0TBAUwAwEB/zANBgkqhkiG9w0BAQUFAAOCAQEAnOXXQ/1O/QTDHyrmQDtFziqPY3xWlJBqJtEqXiT7Y+Ljpe66e+Ee/OjQMlZe8gu21/8cKklH95RxjopMWCVedXDU
07-22 03:52:40.801 I/osp-installer(11904): bool SignatureManager::ValidatePartialReferences(const Tizen::Base::String&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(384) > modified = [bin/WinWin.exe]
07-22 03:52:40.801 I/osp-installer(11904): bool SignatureManager::ValidatePartialReferences(const Tizen::Base::String&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(394) > uriList.size = [1]
07-22 03:52:40.991 I/osp-installer(11904): bool SignatureManager::ValidatePartialReferences(const Tizen::Base::String&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(398) > Signature validator.checkList() success, file = [author-signature.xml], number = [-1]
07-22 03:52:40.991 I/osp-installer(11904): bool SignatureManager::ValidatePartialReferences(const Tizen::Base::String&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(420) > ValidateSignatures done successfully <<
07-22 03:52:41.001 I/osp-installer(11904): static bool InstallerUtil::IsAuthorSignatureVerificationEnabled()(1280) > [author-signature is on.]
07-22 03:52:41.001 I/osp-installer(11904): bool SignatureManager::ValidateUpdate()(262) > ------------------------------------------
07-22 03:52:41.001 I/osp-installer(11904): bool SignatureManager::ValidateUpdate()(263) > oldCert = [MIIClTCCAX2gAwIBAgIGAUcrnHnmMA0GCSqGSIb3DQEBBQUAMFYxGjAYBgNVBAoMEVRpemVuIEFzc29jaWF0aW9uMRowGAYDVQQLDBFUaXplbiBBc3NvY2lhdGlvbjEcMBoGA1UEAwwTVGl6ZW4gRGV2ZWxvcGVycyBDQTAeFw0xMjExMDEwMDAwMDBaFw0xOTAxMDEwMDAwMDBaMBExDzANBgNVBAMMBmF1dGhvcjCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAkSMrcuj6qd8kvc2wiOTMvDXhCJPJeZ34D3jCAil0YBiDQHWvhHniZMtnDIHLO5aDMSzu8l+IC1HF2/6BKj/HXwp5ZuBwb3tG9vBUMFfFnWVn+H/jffRZupuT3OKR1N9bpmx3dmq5KaTO1CpJX4n1eJWXvw5gLKYXT1YD2HqV6fECAwEAAaMyMDAwDAYDVR0TAQH/BAIwADALBgNVHQ8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwDQYJKoZIhvcNAQEFBQADggEBALg/IbnXBacNR3MA+4AnZIyphgzVJA3m5bi2J1qVmb/Cx9/uMXUQgVjNMipzbTMbisMXpSiF+BwxAHKRJeEdKcgQcyLiXz1mCsOBIeQutdBgyPx2hL7JKjTQsxTLTxk4Dc2XFHD4Nk9QLqMfzHD6Zn3lcCsbi2S+z94We3Pr276/ec15fiWsGcPYJcfrBxq2wvQgYrL0Cb2hzPlFMXqfjfTp5wH0GFpKFZwltLzBP3NNd1jpI8SIdH+czSp/a0xp2ua97FNJuHPxA9XDVyDo/5cErY9p2pjGDgxN+yDh5wOmnyr1HkqdyF30yHznD+YSxt1iXa3tt+RhK1YMCEvByuA=]
07-22 03:52:41.001 I/osp-installer(11904): bool SignatureManager::ValidateUpdate()(264) > newCert = [MIIClTCCAX2gAwIBAgIGAUcrnHnmMA0GCSqGSIb3DQEBBQUAMFYxGjAYBgNVBAoMEVRpemVuIEFzc29jaWF0aW9uMRowGAYDVQQLDBFUaXplbiBBc3NvY2lhdGlvbjEcMBoGA1UEAwwTVGl6ZW4gRGV2ZWxvcGVycyBDQTAeFw0xMjExMDEwMDAwMDBaFw0xOTAxMDEwMDAwMDBaMBExDzANBgNVBAMMBmF1dGhvcjCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEAkSMrcuj6qd8kvc2wiOTMvDXhCJPJeZ34D3jCAil0YBiDQHWvhHniZMtnDIHLO5aDMSzu8l+IC1HF2/6BKj/HXwp5ZuBwb3tG9vBUMFfFnWVn+H/jffRZupuT3OKR1N9bpmx3dmq5KaTO1CpJX4n1eJWXvw5gLKYXT1YD2HqV6fECAwEAAaMyMDAwDAYDVR0TAQH/BAIwADALBgNVHQ8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwDQYJKoZIhvcNAQEFBQADggEBALg/IbnXBacNR3MA+4AnZIyphgzVJA3m5bi2J1qVmb/Cx9/uMXUQgVjNMipzbTMbisMXpSiF+BwxAHKRJeEdKcgQcyLiXz1mCsOBIeQutdBgyPx2hL7JKjTQsxTLTxk4Dc2XFHD4Nk9QLqMfzHD6Zn3lcCsbi2S+z94We3Pr276/ec15fiWsGcPYJcfrBxq2wvQgYrL0Cb2hzPlFMXqfjfTp5wH0GFpKFZwltLzBP3NNd1jpI8SIdH+czSp/a0xp2ua97FNJuHPxA9XDVyDo/5cErY9p2pjGDgxN+yDh5wOmnyr1HkqdyF30yHznD+YSxt1iXa3tt+RhK1YMCEvByuA=]
07-22 03:52:41.001 I/osp-installer(11904): bool SignatureManager::ValidateUpdate()(265) > ------------------------------------------
07-22 03:52:41.001 I/osp-installer(11904): bool SignatureManager::ValidateUpdate()(274) > oldCert, newCert is the same.
07-22 03:52:41.021 I/osp-installer(11904): static bool InstallerUtil::Remove(const Tizen::Base::String&)(96) > Remove(): file=[/opt/apps/IoDrtebcNP/author-signature.xml]
07-22 03:52:41.101 I/osp-installer(11904): bool PermissionManager::CopyForRds(InstallationContext*, Tizen::Base::Collection::IList*, bool&)(336) > copy file from[/opt/usr/apps/tmp/IoDrtebcNP/author-signature.xml] to[/opt/apps/IoDrtebcNP/author-signature.xml]
07-22 03:52:41.101 I/osp-installer(11904): static bool InstallerUtil::Remove(const Tizen::Base::String&)(96) > Remove(): file=[/opt/apps/IoDrtebcNP/signature1.xml]
07-22 03:52:41.191 I/osp-installer(11904): bool PermissionManager::CopyForRds(InstallationContext*, Tizen::Base::Collection::IList*, bool&)(336) > copy file from[/opt/usr/apps/tmp/IoDrtebcNP/signature1.xml] to[/opt/apps/IoDrtebcNP/signature1.xml]
07-22 03:52:41.191 I/osp-installer(11904): static bool InstallerUtil::Remove(const Tizen::Base::String&)(96) > Remove(): file=[/opt/apps/IoDrtebcNP/bin/WinWin.exe]
07-22 03:52:41.431 I/osp-installer(11904): bool PermissionManager::CopyForRds(InstallationContext*, Tizen::Base::Collection::IList*, bool&)(336) > copy file from[/opt/usr/apps/tmp/IoDrtebcNP/bin/WinWin.exe] to[/opt/apps/IoDrtebcNP/bin/WinWin.exe]
07-22 03:52:41.431 I/osp-installer(11904): static bool PermissionManager::SetFileCapability(const Tizen::Base::String&, InstallationContext*)(442) > cap_set_file(/opt/apps/IoDrtebcNP/bin/WinWin.exe, cap_from_text(CAP_NET_RAW,CAP_SYS_CHROOT+i)) called.
07-22 03:52:41.431 I/osp-installer(11904): int SmackManager::SetupPath(const char*, const char*, app_path_type_t, const char*)(392) > [smack] perm_app_setup_path(IoDrtebcNP, /opt/apps/IoDrtebcNP, 5, _)
07-22 03:52:41.431 I/osp-installer(11904): int SmackManager::SetupPath(const char*, const char*, app_path_type_t, const char*)(394) > [smack] perm_app_setup_path(), result = [0]
07-22 03:52:41.431 E/Tizen::Io(11904): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-22 03:52:41.431 I/osp-installer(11904): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(392) > path=[/opt/apps/IoDrtebcNP/bin], mode=[0755], appOwner=[false]
07-22 03:52:41.431 I/osp-installer(11904): int SmackManager::SetupPath(const char*, const char*, app_path_type_t, const char*)(386) > [smack] perm_app_setup_path(IoDrtebcNP, /opt/apps/IoDrtebcNP/bin, 0)
07-22 03:52:41.431 I/osp-installer(11904): int SmackManager::SetupPath(const char*, const char*, app_path_type_t, const char*)(388) > [smack] perm_app_setup_path(), result = [0]
07-22 03:52:41.431 E/Tizen::Io(11904): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-22 03:52:41.431 I/osp-installer(11904): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(392) > path=[/opt/apps/IoDrtebcNP/info/IoDrtebcNP.WinWin], mode=[0644], appOwner=[false]
07-22 03:52:41.431 E/Tizen::Io(11904): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-22 03:52:41.431 I/osp-installer(11904): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(392) > path=[/opt/apps/IoDrtebcNP/info], mode=[0644], appOwner=[false]
07-22 03:52:41.431 I/osp-installer(11904): int SmackManager::SetupPath(const char*, const char*, app_path_type_t, const char*)(386) > [smack] perm_app_setup_path(IoDrtebcNP, /opt/apps/IoDrtebcNP/info, 0)
07-22 03:52:41.431 I/osp-installer(11904): int SmackManager::SetupPath(const char*, const char*, app_path_type_t, const char*)(388) > [smack] perm_app_setup_path(), result = [0]
07-22 03:52:41.431 E/Tizen::Io(11904): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-22 03:52:41.431 I/osp-installer(11904): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(392) > path=[/opt/apps/IoDrtebcNP/res/screen-size-normal], mode=[0644], appOwner=[false]
07-22 03:52:41.431 E/Tizen::Io(11904): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-22 03:52:41.431 I/osp-installer(11904): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(392) > path=[/opt/apps/IoDrtebcNP/res/screen-density-xhigh], mode=[0644], appOwner=[false]
07-22 03:52:41.431 E/Tizen::Io(11904): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-22 03:52:41.431 I/osp-installer(11904): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(392) > path=[/opt/apps/IoDrtebcNP/res], mode=[0644], appOwner=[false]
07-22 03:52:41.441 I/o
End of latest debug message
