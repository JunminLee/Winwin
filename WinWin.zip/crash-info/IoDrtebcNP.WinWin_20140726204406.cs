S/W Version Information
Model: Emulator
Tizen-Version: 2.2.1
Build-Number: Tizen_EMULATOR_20131107.2308
Build-Date: 2013.11.07 23:08:36

Crash Information
Process Name: WinWin
PID: 4542
Date: 2014-07-26 20:44:06(GMT+0900)
Executable File Path: /opt/apps/IoDrtebcNP/bin/WinWin
This process is multi-thread process
pid=4542 tid=4542
Signal: 6
      (SIGABRT)
      si_code: -6
      signal sent by tkill (sent by pid 4542, uid 5000)

Register Information
gs  = 0x00000033, fs  = 0x00000000
es  = 0x0000007b, ds  = 0x0000007b
edi = 0xb73daff4, esi = 0xb73b5043
ebp = 0xbfb3c6c8, esp = 0xbfb3c6b0
eax = 0x00000000, ebx = 0x000011be
ecx = 0x000011be, edx = 0x00000006
eip = 0xb7796424

Memory Information
MemTotal:   509428 KB
MemFree:    150356 KB
Buffers:     14904 KB
Cached:     199820 KB
VmPeak:     105640 KB
VmSize:     101268 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       33280 KB
VmRSS:       29020 KB
VmData:      15776 KB
VmStk:         136 KB
VmExe:          40 KB
VmLib:       61184 KB
VmPTE:         108 KB
VmSwap:          0 KB

Maps Information
08048000 08052000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
b1774000 b1776000 r-xp /usr/lib/libhaptic-module.so
b21e1000 b21ef000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnu-i686-1.7.99/module.so
b21f0000 b21fe000 r-xp /usr/lib/evas/modules/engines/software_x11/linux-gnu-i686-1.7.99/module.so
b2207000 b2221000 r-xp /usr/lib/libnetwork.so.0.0.0
b2223000 b2240000 r-xp /usr/lib/libwifi-direct.so.0.0
b2241000 b224c000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b224d000 b2373000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b237a000 b23a7000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b23ba000 b23e6000 r-xp /opt/usr/apps/IoDrtebcNP/bin/WinWin.exe
b23e9000 b2445000 r-xp /usr/lib/libosp-env-config.so.1.2.2.1
b2446000 b2499000 r-xp /usr/lib/libpulsecommon-0.9.23.so
b249a000 b24a0000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b24a1000 b24a6000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b24a7000 b24ef000 r-xp /usr/lib/libpulse.so.0.12.4
b24f0000 b24f4000 r-xp /usr/lib/libpulse-simple.so.0.0.3
b24f5000 b25e7000 r-xp /usr/lib/libasound.so.2.0.0
b25eb000 b2610000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b2611000 b2625000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2626000 b2707000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b270c000 b276b000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b276c000 b2778000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b2779000 b278c000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b278d000 b2790000 r-xp /usr/lib/libmm_ta.so.0.0.0
b2791000 b27a8000 r-xp /usr/lib/libICE.so.6.3.0
b27ab000 b27b2000 r-xp /usr/lib/libSM.so.6.0.1
b27b3000 b27b4000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b27b5000 b27c0000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b27c1000 b27cc000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b27d0000 b27d4000 r-xp /usr/lib/libmmfsession.so.0.0.0
b27d5000 b2833000 r-xp /usr/lib/libmmfplayer.so.0.0.0
b2835000 b283d000 r-xp /usr/lib/libxcb-render.so.0.0.0
b283e000 b2840000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b2841000 b28a4000 r-xp /usr/lib/libtiff.so.5.1.0
b28a7000 b28f9000 r-xp /usr/lib/libturbojpeg.so
b290a000 b2911000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2912000 b291b000 r-xp /usr/lib/libgif.so.4.1.6
b291c000 b2942000 r-xp /usr/lib/libavutil.so.51.73.101
b2949000 b298e000 r-xp /usr/lib/libswscale.so.2.1.101
b298f000 b2cf4000 r-xp /usr/lib/libavcodec.so.54.59.100
b3015000 b303c000 r-xp /usr/lib/libpng12.so.0.50.0
b303d000 b3044000 r-xp /usr/lib/libfeedback.so.0.1.4
b3045000 b3054000 r-xp /usr/lib/libtts.so
b3055000 b306b000 r-xp /usr/lib/host-gl/libEGL.so.1.0
b306c000 b3186000 r-xp /usr/lib/libcairo.so.2.11200.12
b3189000 b31ae000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b31af000 b4013000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.1
b4086000 b408c000 r-xp /usr/lib/libslp_devman_plugin.so
b408d000 b4091000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b4092000 b4097000 r-xp /usr/lib/libsysman.so.0.2.0
b4098000 b40b0000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b40b1000 b40b3000 r-xp /usr/lib/libsystemd-daemon.so.0.0.1
b40b4000 b40b6000 r-xp /usr/lib/libdeviced.so.0.1.0
b40b7000 b40d4000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b40d5000 b40d7000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b40d8000 b40db000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b40dc000 b40e0000 r-xp /usr/lib/libdevice-node.so.0.1
b40e1000 b40e5000 r-xp /usr/lib/libheynoti.so.0.0.2
b40e6000 b414f000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4151000 b4170000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b4171000 b4176000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b4177000 b417d000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b417e000 b4180000 r-xp /usr/lib/libcapi-system-power.so.0.1.1
b4181000 b4185000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b4186000 b418b000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b418c000 b418f000 r-xp /usr/lib/libcapi-network-serial.so.0.0.8
b4190000 b4191000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b4192000 b41a5000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b41a7000 b41d7000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b41d8000 b41dc000 r-xp /usr/lib/libuuid.so.1.3.0
b41dd000 b4204000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b4205000 b421a000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b421b000 b421c000 r-xp /usr/lib/libpmapi.so.1.2
b421d000 b4229000 r-xp /usr/lib/libminizip.so.1.0.0
b422a000 b4239000 r-xp /usr/lib/libmessage-port.so.1.2.2.1
b423a000 b4383000 r-xp /usr/lib/libxml2.so.2.7.8
b4389000 b43b1000 r-xp /usr/lib/libpcre.so.0.0.1
b43b2000 b43b5000 r-xp /usr/lib/libiniparser.so.0
b43b7000 b43bc000 r-xp /usr/lib/libhaptic.so.0.1
b43bd000 b43be000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b43bf000 b43c6000 r-xp /usr/lib/libdevman.so.0.1
b43c7000 b43cd000 r-xp /usr/lib/libchromium.so.1.0
b43ce000 b43d6000 r-xp /usr/lib/libappsvc.so.0.1.0
b43d7000 b43d9000 r-xp /usr/lib/osp/libappinfo.so.1.2.2.1
b43da000 b43e2000 r-xp /usr/lib/libalarm.so.0.0.0
b43e3000 b43ed000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.3
b43ee000 b4407000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.5
b4408000 b489b000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.1
b48bc000 b48c6000 r-xp /lib/libnss_files-2.13.so
b48c8000 b48d1000 r-xp /lib/libnss_nis-2.13.so
b48d3000 b48e6000 r-xp /lib/libnsl-2.13.so
b48ea000 b48f0000 r-xp /lib/libnss_compat-2.13.so
b4c12000 b4c2a000 r-xp /usr/lib/libcom-core.so.0.0.1
b4c2b000 b4c2e000 r-xp /usr/lib/libdri2.so.0.0.0
b4c2f000 b4c3a000 r-xp /usr/lib/libdrm.so.2.4.0
b4c3b000 b4c40000 r-xp /usr/lib/libtbm.so.1.0.0
b4c41000 b4c45000 r-xp /usr/lib/libXv.so.1.0.0
b4c46000 b4d63000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4d72000 b4d88000 r-xp /usr/lib/libnotification.so.0.1.0
b4d89000 b4d92000 r-xp /usr/lib/libutilX.so.1.1.0
b4d93000 b4dc6000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4dc8000 b4dd9000 r-xp /lib/libresolv-2.13.so
b4ddd000 b4de0000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4de1000 b4f51000 r-xp /usr/lib/libcrypto.so.1.0.0
b4f69000 b4fbf000 r-xp /usr/lib/libssl.so.1.0.0
b4fc4000 b4ff3000 r-xp /usr/lib/libidn.so.11.5.44
b4ff4000 b5003000 r-xp /usr/lib/libcares.so.2.0.0
b5004000 b502b000 r-xp /lib/libexpat.so.1.5.2
b502d000 b5060000 r-xp /usr/lib/libicule.so.48.1
b5061000 b506c000 r-xp /usr/lib/libsf_common.so
b506d000 b5149000 r-xp /usr/lib/libstdc++.so.6.0.14
b5155000 b52ba000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b52be000 b52ef000 r-xp /usr/lib/libexif.so.12.3.3
b52fc000 b5308000 r-xp /usr/lib/libethumb.so.1.7.99
b5309000 b536d000 r-xp /usr/lib/libsndfile.so.1.0.25
b5373000 b5376000 r-xp /usr/lib/libctxdata.so.0.0.0
b5377000 b538e000 r-xp /usr/lib/libremix.so.0.0.0
b538f000 b5391000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b5392000 b53bf000 r-xp /usr/lib/liblua-5.1.so
b53c0000 b53ca000 r-xp /usr/lib/libembryo.so.1.7.99
b53cb000 b53ce000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b53cf000 b5430000 r-xp /usr/lib/libcurl.so.4.3.0
b5432000 b5438000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b5439000 b54d0000 r-xp /usr/lib/libpixman-1.so.0.28.2
b54d5000 b550a000 r-xp /usr/lib/libfontconfig.so.1.5.0
b550c000 b5591000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b559b000 b55b1000 r-xp /usr/lib/libfribidi.so.0.3.1
b55b2000 b5637000 r-xp /usr/lib/libfreetype.so.6.8.1
b563b000 b5682000 r-xp /usr/lib/libjpeg.so.8.0.2
b5693000 b56b2000 r-xp /lib/libz.so.1.2.5
b56b3000 b56c3000 r-xp /usr/lib/libsensor.so.1.1.0
b56c6000 b56c9000 r-xp /usr/lib/libapp-checker.so.0.1.0
b56ca000 b56d3000 r-xp /usr/lib/libxdgmime.so.1.1.0
b67dc000 b6937000 r-xp /usr/lib/libicuuc.so.48.1
b6945000 b6b24000 r-xp /usr/lib/libicui18n.so.48.1
b6b2b000 b6b2e000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6b2f000 b6b3b000 r-xp /usr/lib/libvconf.so.0.2.45
b6b3c000 b6b4e000 r-xp /usr/lib/libail.so.0.1.0
b6b4f000 b6b74000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b6b75000 b6b7a000 r-xp /usr/lib/libffi.so.5.0.10
b6b7b000 b6b7c000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b6b7d000 b6b8e000 r-xp /usr/lib/libXext.so.6.4.0
b6b8f000 b6b94000 r-xp /usr/lib/libXtst.so.6.1.0
b6b95000 b6b9d000 r-xp /usr/lib/libXrender.so.1.3.0
b6b9e000 b6ba7000 r-xp /usr/lib/libXrandr.so.2.2.0
b6ba8000 b6bb6000 r-xp /usr/lib/libXi.so.6.1.0
b6bb7000 b6bbb000 r-xp /usr/lib/libXfixes.so.3.1.0
b6bbc000 b6bbe000 r-xp /usr/lib/libXgesture.so.7.0.0
b6bbf000 b6bc1000 r-xp /usr/lib/libXcomposite.so.1.0.0
b6bc2000 b6bc4000 r-xp /usr/lib/libXdamage.so.1.1.0
b6bc5000 b6bcf000 r-xp /usr/lib/libXcursor.so.1.0.2
b6bd0000 b6bdc000 r-xp /usr/lib/libemotion.so.1.7.99
b6bdd000 b6c08000 r-xp /usr/lib/libecore_con.so.1.7.99
b6c0a000 b6c12000 r-xp /usr/lib/libecore_imf.so.1.7.99
b6c13000 b6c1e000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6c1f000 b6c22000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6c23000 b6c29000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6c2a000 b6c4c000 r-xp /usr/lib/libefreet.so.1.7.99
b6c4e000 b6c5a000 r-xp /usr/lib/libedbus.so.1.7.99
b6c5b000 b6cf2000 r-xp /usr/lib/libedje.so.1.7.99
b6cf4000 b6d0b000 r-xp /usr/lib/libecore_input.so.1.7.99
b6d1f000 b6d26000 r-xp /usr/lib/libecore_file.so.1.7.99
b6d27000 b6d54000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6d56000 b6db1000 r-xp /usr/lib/libeina.so.1.7.99
b6db3000 b6ebd000 r-xp /usr/lib/libevas.so.1.7.99
b6ed8000 b6ef5000 r-xp /usr/lib/libeet.so.1.7.99
b6ef6000 b6f1a000 r-xp /lib/libm-2.13.so
b6f1c000 b6f22000 r-xp /usr/lib/libappcore-common.so.1.1
b6f23000 b6f33000 r-xp /usr/lib/libaul.so.0.1.0
b6f34000 b6f84000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6f85000 b6fc8000 r-xp /usr/lib/libecore_x.so.1.7.99
b6fca000 b6fe9000 r-xp /usr/lib/libecore.so.1.7.99
b6ff8000 b71ca000 r-xp /usr/lib/libelementary.so.1.7.99
b71d6000 b71e3000 r-xp /usr/lib/libcapi-network-connection.so.0.1.3_18
b71e4000 b71e6000 r-xp /opt/usr/apps/IoDrtebcNP/bin/WinWin
b71e9000 b71ed000 r-xp /lib/libattr.so.1.1.0
b71ee000 b71f0000 r-xp /usr/lib/libXau.so.6.0.0
b71f1000 b71f8000 r-xp /lib/librt-2.13.so
b71fb000 b7203000 r-xp /lib/libcrypt-2.13.so
b722c000 b722f000 r-xp /lib/libcap.so.2.21
b7230000 b7232000 r-xp /usr/lib/libiri.so
b7233000 b724d000 r-xp /lib/libgcc_s-4.5.3.so.1
b724e000 b726e000 r-xp /usr/lib/libxcb.so.1.1.0
b7270000 b7279000 r-xp /lib/libunwind.so.8.0.1
b7283000 b73d9000 r-xp /lib/libc-2.13.so
b73df000 b73e4000 r-xp /usr/lib/libsmack.so.1.0.0
b73e5000 b7431000 r-xp /usr/lib/libdbus-1.so.3.7.2
b7432000 b7437000 r-xp /usr/lib/libbundle.so.0.1.22
b7438000 b743a000 r-xp /lib/libdl-2.13.so
b743c000 b7565000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b7566000 b7610000 r-xp /usr/lib/libsqlite3.so.0.8.6
b7613000 b7625000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b7626000 b775b000 r-xp /usr/lib/libX11.so.6.3.0
b775f000 b7774000 r-xp /lib/libpthread-2.13.so
b777a000 b777b000 r-xp /usr/lib/libdlog.so.0.0.0
b777c000 b777e000 r-xp /usr/lib/libXinerama.so.1.0.0
b777f000 b7785000 r-xp /usr/lib/libecore_fb.so.1.7.99
b7787000 b778c000 r-xp /usr/lib/libappcore-efl.so.1.1
b778e000 b7792000 r-xp /usr/lib/libsys-assert.so
b7796000 b7797000 r-xp [vdso]
b7797000 b77b3000 r-xp /lib/ld-2.13.so
End of Maps Information

Callstack Information (PID:4542)
Call Stack Count: 55
 0: __assert_fail + 0xf8 (0xb72a6888) [/lib/libc.so.6] + 0x23888
 1: SysAssertfInternal + 0x107 (0xb457fa67) [/usr/lib/osp/libosp-appfw.so] + 0x177a67
 2: Tizen::Ui::Controls::Panel::SetBackgroundColor(Tizen::Graphics::Color const&) + 0x6c (0xb36159cc) [/usr/lib/osp/libosp-uifw.so] + 0x4669cc
 3: PartnerListForm::OnInitializing() + 0xea9 (0xb23cca39) [/opt/apps/IoDrtebcNP/bin/WinWin.exe] + 0x12a39
 4: Tizen::Ui::_ControlImpl::OnAttachedToMainTree() + 0x39 (0xb34e3439) [/usr/lib/osp/libosp-uifw.so] + 0x334439
 5: Tizen::Ui::Controls::_FormImpl::OnAttachedToMainTree() + 0x48 (0xb3845888) [/usr/lib/osp/libosp-uifw.so] + 0x696888
 6: Tizen::Ui::_Control::CallOnAttachedToMainTree(Tizen::Ui::_Control&) + 0x115 (0xb34b84e5) [/usr/lib/osp/libosp-uifw.so] + 0x3094e5
 7: Tizen::Ui::_Control::EndAttaching(Tizen::Ui::_Control&) + 0x26e (0xb34bedce) [/usr/lib/osp/libosp-uifw.so] + 0x30fdce
 8: Tizen::Ui::_Control::AttachChild(Tizen::Ui::_Control&) + 0xba (0xb34c280a) [/usr/lib/osp/libosp-uifw.so] + 0x31380a
 9: Tizen::Ui::_ContainerImpl::AddChild(Tizen::Ui::_ControlImpl*, bool) + 0xec (0xb34fa59c) [/usr/lib/osp/libosp-uifw.so] + 0x34b59c
10: Tizen::Ui::Container::AddControl(Tizen::Ui::Control*) + 0x52 (0xb34ae632) [/usr/lib/osp/libosp-uifw.so] + 0x2ff632
11: Tizen::Ui::Container::AddControl(Tizen::Ui::Control const&) + 0x24 (0xb34ae714) [/usr/lib/osp/libosp-uifw.so] + 0x2ff714
End of Call Stack

Package Information
Package Name: IoDrtebcNP.WinWin
Package ID : IoDrtebcNP
Version: 1.0.0
Package Type: tpk
App Name: WinWin
App ID: IoDrtebcNP.WinWin
Type: Application
Categories: (NULL)
